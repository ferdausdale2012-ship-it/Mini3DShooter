plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mini3dshooter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.mini3dshooter"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.13.0")
}
