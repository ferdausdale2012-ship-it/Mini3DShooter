# Mini 3D Shooter — Android APK

এটি একটি Android WebView wrapper প্রজেক্ট। `index.html` গেমটি অ্যাপের ভিতরে চালায়।

## মোবাইল থেকেই APK বানানো

1. এই ZIP ফাইলটি extract করো।
2. GitHub-এ নতুন repository তৈরি করো, যেমন `Mini3DShooter`।
3. Extract করা ফোল্ডারের ভেতরের ফাইলগুলো repository-তে upload করো। `.github/workflows/build-apk.yml` ফাইলটিও upload হয়েছে কি না নিশ্চিত করো।
4. GitHub repository-র **Actions** tab খোলো।
5. **Build Mini 3D Shooter APK** workflow বেছে **Run workflow** চাপো।
6. Build শেষ হলে workflow run-এর নিচে **Artifacts** অংশ থেকে `Mini3DShooter-debug-apk` ডাউনলোড করো।
7. ZIP artifact extract করে `app-debug.apk` বের করো।
8. APK-তে চাপ দিয়ে Android-এর নির্দেশনা অনুসরণ করে install করো। প্রয়োজনে Settings-এ “Install unknown apps” অনুমতি দিতে হবে।

## গুরুত্বপূর্ণ

- গেমটি Three.js CDN থেকে লোড করে, তাই গেম চালানোর সময় ইন্টারনেট দরকার।
- এটি debug APK, Play Store release নয়।
- প্রথম build ব্যর্থ হলে Actions-এর build log দেখো; Android/Gradle plugin version বা dependency download সমস্যা হতে পারে।
- `app/src/main/assets/index.html`-এ গেমের HTML রাখা আছে।
